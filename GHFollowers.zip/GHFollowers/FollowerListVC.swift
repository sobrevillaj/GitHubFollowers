//
//  FollowerListVC.swift
//  GHFollowers
//
//  Created by Jessi on 9/3/20.
//  Copyright © 2020 Jessi. All rights reserved.
//

import UIKit

class FollowerListVC: UIViewController {
    
    var username: String

    override func viewDidLoad() {
        super.viewDidLoad()

    }
    
}
