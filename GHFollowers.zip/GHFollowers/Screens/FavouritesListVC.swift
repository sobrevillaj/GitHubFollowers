//
//  FavouritesListVC.swift
//  GHFollowers
//
//  Created by Jessi on 9/2/20.
//  Copyright © 2020 Jessi. All rights reserved.
//

import UIKit

class FavouritesListVC: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .systemBlue
    }
}
