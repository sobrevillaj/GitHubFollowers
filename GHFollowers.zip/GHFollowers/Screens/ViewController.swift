//
//  ViewController.swift
//  GHFollowers
//
//  Created by Jessi on 9/1/20.
//  Copyright © 2020 Jessi. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .systemPink      
    }


}

