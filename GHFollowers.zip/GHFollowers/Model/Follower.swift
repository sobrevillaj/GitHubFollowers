//
//  Follower.swift
//  GHFollowers
//
//  Created by Jessi on 9/8/20.
//  Copyright © 2020 Jessi. All rights reserved.
//

import Foundation

struct Follower: Codable, Hashable {
    var login: String
    var avatarUrl: String
}
